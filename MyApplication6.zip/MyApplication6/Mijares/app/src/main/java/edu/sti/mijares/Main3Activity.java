package edu.sti.mijares;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {


    TextView tv_email , tv_username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        tv_email = (TextView) findViewById(R.id.textView4);
        tv_username = (TextView) findViewById(R.id.textView5);

        //putting all together
        SharedPreferences resulta = getSharedPreferences("USERINFORMATION" , Context.MODE_PRIVATE);
        String email = resulta.getString("EMAIL" , "");
        String user = resulta.getString("USER" , "");

        tv_email.setText(email);
        tv_username.setText(user);
    }
}
