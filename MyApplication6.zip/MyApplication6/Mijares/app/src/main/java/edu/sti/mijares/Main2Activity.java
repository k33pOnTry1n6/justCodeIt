package edu.sti.mijares;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {


    EditText et_user , et_pass;
    Button btn_log , btn_reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        et_user = (EditText) findViewById(R.id.et_user);
        et_pass = (EditText) findViewById(R.id.et_pass);

        btn_reg = (Button) findViewById(R.id.btn_reg);
        btn_log = (Button) findViewById(R.id.btn_log);

        //Deretcho sa third activity
        btn_log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences result = getSharedPreferences("USERINFORMATION" , Context.MODE_PRIVATE);
                String user = result.getString("USER" , "");
                String pass = result.getString("PASS" , "");

                if (et_user.getText().toString().trim().equals(user) && et_pass.getText().toString().trim().equals(pass)){
                    Intent intent = new Intent(Main2Activity.this , Main3Activity.class);
                    startActivity(intent);

                }else if (et_user.getText().toString().trim().equals("") && et_pass.getText().toString().trim().equals("")) {
                    Toast.makeText(Main2Activity.this, "Please Enter your Username and Password", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(Main2Activity.this, "Try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //Back to registration form
        btn_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ints = new Intent(Main2Activity.this , MainActivity.class);
                startActivity(ints);
            }
        });

    }
}
